<?php
	
$mysqli = new mysqli("localhost", "root", "", "er_mahasiswa");
if($mysqli->connect_errno)
{
	die($mysqli->connect_errno);
}

//DATA DARI FORM
$terima = $_POST['terima'];
$nama = $_POST['nama'];
$lahir = $_POST['lahir'];
$email = $_POST['email'];
$ipk = $_POST['ipk'];
$idProdi = $_POST['idProdi'];


//GENERATE NRP
$NRP = "";
//MENDAPAT ID PRODI
$query = "SELECT * FROM prodi";
$statement = $mysqli->prepare($query);
$statement->execute();
$result = $statement->get_result();
$i = 0;
$prodi = array();
$daftarProdi = array();
if($result)
{
  while ($row = $result-> fetch_assoc()) 
  {
    $prodi['Nama'] = $row['Nama'];
    $prodi['IdFakultas'] = $row['IdFakultas'];
    $prodi['PrefixNrp'] = $row['PrefixNrp'];
    
    $daftarProdi[$i] = $prodi;
    $i++;
  }  
}

for($a=0; $a<count($daftarProdi); $a++){
	if($idProdi == $daftarProdi[$a]['IdFakultas']){
		$NRP = $daftarProdi[$a]['PrefixNrp'];
	}
}

//Tahun terima
$NRP = $NRP . $terima;

//Nomor urut
$query2 = "SELECT * FROM mahasiswa";
$statement2 = $mysqli->prepare($query2);
$statement2->execute();
$result2 = $statement2->get_result();
$j = 0;
$mahasiswa = array();
$daftarMahasiswa = array();
if($result2)
{
  while ($row2 = $result2-> fetch_assoc()) 
  {
    $mahasiswa['Nrp'] = $row2['Nrp'];
    $daftarMahasiswa[$j] = $mahasiswa;
    $j++;
  }  
}

$noUrut = 1;
for($b=0; $b < count($daftarMahasiswa); $b++){
	//cek 6 angka di depan
	if(substr($daftarMahasiswa[$b]['Nrp'], 0, 6) == $NRP){
		//cek 3 angka sisanya
		while((int)(substr($daftarMahasiswa[$b]['Nrp'], 6)) == $noUrut){
			$noUrut++;
		}
	}
}
$noUrutNow = "";
//cek apakah perlu ditambahkan 0 di depannya
$check = strlen((string)$noUrut);
if($check == 2){
	$noUrutNow = "0".strval($noUrut);
}
else if($check == 1){
	$noUrutNow = "00".strval($noUrut);
}
else{
	$noUrutNow = strval($noUrut);
}

//NRP FINAL
$NRP = $NRP.$noUrutNow;

//TAMBAH DATA DI TABEL MAHASISWA
$query3 = "INSERT INTO mahasiswa (Nrp, ThnTerima, Nama, TglLahir, Email, Ipk, IdProdi) VALUES 
($NRP, $terima, $nama, $lahir, $email, $ipk, $idProdi)";
//$datetime = date("Y-m-d H:i:s");
if($statement3 = $mysqli->prepare($query3))
{
	$statement3->execute();
	echo "0";
}
?>