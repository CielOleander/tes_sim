<?php
	
$mysqli = new mysqli("localhost", "root", "", "er_mahasiswa");
if($mysqli->connect_errno)
{
	die($mysqli->connect_errno);
}

if(isset($_POST['submit'])){
	$NRP = $_GET['id'];
	$terima = $_POST['terima'];
	$nama = $_POST['nama'];
	$lahir = $_POST['lahir'];
	$email = $_POST['email'];
	$ipk = $_POST['ipk'];
	$idProdi = $_POST['idProdi'];

	//UPDATE DATA DI TABEL MAHASISWA
	$query3 = "UPDATE mahasiswa SET 
	ThnTerima ='$terima',
	Nama='$nama',
	TglLahir = '$lahir',
	Email = '$email',
	Ipk = '$ipk',
	IdProdi = '$idProdi' 
	WHERE Nrp='$NRP'";

	$mysqli->query($query3);
	$mysqli->commit();
	header('Location: http://localhost:80/tes_sim/daftar.php');
}
?>