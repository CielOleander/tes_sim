<?php

$db = mysqli_connect("localhost","root","","er_mahasiswa");

if(!$db)
{
    die("Connection failed: " . mysqli_connect_error());
}
 
$NRP = $_GET['id']; // get id through query string

$del = mysqli_query($db,"DELETE FROM mahasiswa where Nrp = '$NRP'"); // delete query

if($del)
{
    mysqli_close($db); // Close connection
    header('Location: http://localhost:80/tes_sim/daftar.php');	
}
else
{
    echo "Error deleting record"; // display error message if not delete
}
?>