<?php 

$mysqli = new mysqli("localhost", "root", "", "er_mahasiswa");
if($mysqli->connect_errno)
{
	die($mysqli->connect_errno);
}

$partialInfo = "%".$_POST["partialInfo"]."%";

$friends = "SELECT * FROM mahasiswa WHERE Nama LIKE ?";
if($statement = $mysqli->prepare($friends))
	{
	//bind parameter
	$statement->bind_param("s", $partialInfo);
	$statement->execute();
	}
$result = $statement->get_result();
echo "<tr>
                <th>NRP</th>
                <th>Tahun Terima</th>
                <th>Nama</th>
                <th>Tanggal Lahir</th>
                <th>Email</th>
                <th>IPK</th>
                <th>Id Prodi</th>
                <th></th>
                <th></th>
              </tr>";
 	//while untuk friend
 	while($friends = $result->fetch_assoc())
{echo "
                  <tr>
                  <td>".$friends['Nrp']."</td>".
                  "<td>".$friends['ThnTerima']."</td>".
                  "<td>".$friends['Nama']."</td>".
                  "<td>".$friends['TglLahir']."</td>".
                  "<td>".$friends['Email']."</td>".
                  "<td>".$friends['Ipk']."</td>".
                  "<td>".$friends['IdProdi']."</td>".
                  "<td><a href=http://localhost/tes_sim/detail.php?id=".$friends['Nrp']." class=btn btn-sm btn-primary>Detail</a></td>".
                  "<td><a href=http://localhost/tes_sim/delete_posting.php?id=".$friends['Nrp']." class=btn btn-sm btn-primary>Delete</a></td></tr>";
}
?>